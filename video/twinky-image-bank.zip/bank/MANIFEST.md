# Twinky image bank

22 assets in four folders. Every number and every message in here is **real, from the committed
fixtures** — nothing is invented.

**Read the usage rules in §5 before cutting anything.** The folders are not interchangeable, and
one of them must never be used as product proof.

---

## 01-real/ — genuine captured artifacts

Frames pulled straight from `evals/fixtures/stableronaldo_2026-08-30T0723/raw/frames/`. These are
what the camera actually saw. **These are product proof and can be shown as such.**

| file | what it is |
|---|---|
| `00-41_wordgame_ranger.jpg` | the overlay early in the capture; chat is guessing `rang…` |
| `02-00_wordgame_ame.jpg` | `ame_______` — chat types amethyst, American, amendment |
| `08-30_wordgame_par___.jpg` | `p a r _ _ _` |
| `09-30_wordgame_para_.jpg` | **the hero frame.** 3:32 am, three people asleep, `GUESS THE WORD! p a r a _`, chat visibly typing parag / paray / paral / parax |

`09-30_wordgame_para_.jpg` is the single strongest asset in the project. Zero audio in the entire
12-minute capture, so the frame is the only possible explanation for what chat is doing. That is
the thesis with no argument required.

⚠ **These frames have real Twitch logins burned into the overlay.** Your fixtures pseudonymise
every chatter, and your README says so. Blur the username column before this goes in the video,
or you are showing on camera exactly what the pipeline is documented as not storing.

## 02-product-stills/ — rendered from real data, in the design system

| file | data behind it |
|---|---|
| `01_title_twinky.png` | title card |
| `02_thesis_chat_is_response.png` | the `10` example |
| `03_raw_chat_flood.png` | 48 real messages from the `para_` window |
| `04_board_wordgame_para.png` | para… 38 · part… 18 · parr… 5 · heli… 5, over 123 messages |
| `17_board_wordgame_ranger.png` | rang… 21 · rand… 11 · stre… 10 · ranc… 8, over 173 messages |
| `05_board_violet_27.png` | violet 27 · myers 13 · wtf 11 · noah 9, under the real quote *"What the fuck is going on?"* |
| `06_questions_panel.png` | the unanswered-question rows |
| `07_gate_ledger.png` | 19 rejected: E_CIRCULAR_EVIDENCE 15, E_UNKNOWN_MSG 3, E_TRIGGER_LATE 1 |
| `08_metrics_table.png` | the frozen 11-case table, ablation winning |
| `09_mechanism_table.png` | where each arm's triggers came from — 0 frame ids vs 4 |
| `11_reproducibility.png` | 48 hits / 0 misses · 530 tests · $0.43 |
| `16_before_after_split.png` | raw chat on the left, the board on the right, same minute |

`16_before_after_split.png` is the one that explains the product in a single frame. If the video
only has room for one graphic, use that.

## 03-titles/ — typography, safe to cut directly

`10_hot_take.png` · `12_end_card.png` · `18_lower_third.png`

`10_hot_take.png` carries the line the whole submission turns on: *"The ablation won by knowing
less and saying nothing. This arm lost by knowing more and always committing."*

## 04-mood/ — Dreamina reference plates only

`13_orbs_warm.png` · `14_orbs_cool.png` · `15_palette.png`

Feed these to Dreamina as style references to pull generated footage toward the product's palette
— warm off-white, pastel atmosphere, no saturated accent. They make no claim about anything and
should never appear in the cut on their own.

---

## 5. Usage rules

**`01-real/` is product proof.** Real capture, showable as evidence.

**`02-product-stills/` and `03-titles/` are graphics you authored.** They are honest — every
figure in them is measured — but they are *renderings*, not screenshots of the running app. Cut
them as titles, lower thirds and explanatory graphics. **Never cut them so they read as a screen
recording of the interface.** When the video claims "here is the product running," that footage
must be an actual screen recording of `make demo`. This is your own shot-list rule and it is the
one a judge would most easily catch you breaking.

**`04-mood/` is reference input, not footage.**

**Nothing here may be edited to change a number.** If a figure moves — and the eval numbers may
still move — re-render rather than retouching a PNG.

## 6. Specs

1920 × 1080, PNG, sRGB. Canvas `#f5f5f5`, ink `#0c0a09`, hairlines `#e7e5e4`, orbs mint / peach /
lavender / sky / rose. Display type weight 300 throughout, hairlines instead of shadows, no
saturated accent anywhere. Rendered headless at 1× — regenerate at a higher device scale factor
if you need 4K.

Source: `build_bank.py`, which reads the fixtures directly. Re-run it after the eval numbers
change and every still updates from the data.
