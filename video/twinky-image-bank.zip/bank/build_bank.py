#!/usr/bin/env python3
"""Render the Twinky image bank: on-brand product stills from REAL fixture data."""
import json, pathlib, html

D = json.load(open("/home/claude/realdata.json"))
OUT = pathlib.Path("/home/claude/bank"); OUT.mkdir(exist_ok=True)

CSS = """
@page{margin:0}
*{margin:0;padding:0;box-sizing:border-box}
:root{
--canvas:#f5f5f5; --soft:#fafafa; --card:#ffffff; --strong:#f0efed;
--ink:#0c0a09; --primary:#292524; --body:#4e4e4e; --muted:#777169; --msoft:#a8a29e;
--hair:#e7e5e4; --hair2:#f0efed; --hair3:#d6d3d1;
--mint:#a7e5d3; --peach:#f4c5a8; --lav:#c8b8e0; --sky:#a8c8e8; --rose:#e8b8c4;
--disp:"DejaVu Sans Light","Carlito",sans-serif;
--ui:"Carlito","DejaVu Sans",sans-serif;
--mono:"DejaVu Sans Mono",monospace;
}
body{background:#222;font-family:var(--ui)}
.frame{width:1920px;height:1080px;background:var(--canvas);position:relative;overflow:hidden;
  margin:0 0 40px;color:var(--ink)}
.orb{position:absolute;border-radius:50%;filter:blur(120px);opacity:.55;pointer-events:none}
.pad{position:relative;z-index:2;height:100%;padding:96px 120px;display:flex;flex-direction:column}
h1{font-family:var(--disp);font-weight:300;font-size:104px;line-height:1.04;letter-spacing:-3px}
h2{font-family:var(--disp);font-weight:300;font-size:64px;line-height:1.08;letter-spacing:-1.4px}
h3{font-family:var(--disp);font-weight:300;font-size:40px;line-height:1.15;letter-spacing:-.5px}
.kick{font-size:15px;font-weight:600;letter-spacing:1.6px;text-transform:uppercase;color:var(--muted)}
.body{font-size:24px;line-height:1.55;letter-spacing:.2px;color:var(--body);max-width:58ch}
.small{font-size:17px;line-height:1.5;color:var(--muted);letter-spacing:.16px}
.mono{font-family:var(--mono);font-size:16px;color:var(--muted)}
.pill{display:inline-flex;align-items:center;gap:9px;padding:8px 18px;border:1px solid var(--hair3);
  border-radius:9999px;font-size:14px;letter-spacing:1px;text-transform:uppercase;color:var(--primary);
  font-weight:600;background:var(--card)}
.pill.ink{background:var(--primary);color:#fff;border-color:var(--primary)}
.dot{width:7px;height:7px;border-radius:50%;background:currentColor;display:inline-block}
.card{background:var(--card);border:1px solid var(--hair);border-radius:16px;padding:32px}
.rule{height:1px;background:var(--hair);margin:36px 0}
.spacer{flex:1}
.mark{display:flex;align-items:center;gap:16px;font-size:26px;letter-spacing:.2px;color:var(--ink)}
.mark svg{display:block}
.foot{display:flex;align-items:center;justify-content:space-between;font-size:16px;color:var(--msoft);
  letter-spacing:.6px}
/* board */
.row{display:grid;grid-template-columns:1fr 120px;gap:20px;align-items:center;padding:14px 0;
  border-bottom:1px solid var(--hair2)}
.row .lbl{font-size:30px;letter-spacing:-.2px;color:var(--ink)}
.row .lbl small{display:block;font-size:16px;color:var(--msoft);margin-top:6px;letter-spacing:.2px}
.row .n{font-family:var(--mono);font-size:34px;text-align:right;color:var(--ink)}
.bar{height:3px;background:var(--ink);border-radius:2px;margin-top:10px;opacity:.85}
.trigger{border-left:2px solid var(--ink);padding:6px 0 6px 24px;margin:8px 0 28px}
.trigger .q{font-family:var(--disp);font-weight:300;font-size:38px;letter-spacing:-.4px;line-height:1.25}
.trigger .meta{font-family:var(--mono);font-size:15px;color:var(--muted);margin-top:12px;letter-spacing:.4px}
/* flood */
.flood{columns:4;column-gap:44px;font-family:var(--mono);font-size:19px;line-height:1.85;color:var(--body)}
.flood span{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
/* table */
table{width:100%;border-collapse:collapse;font-size:24px}
th{text-align:left;font-size:14px;font-weight:600;letter-spacing:1.4px;text-transform:uppercase;
  color:var(--muted);padding:0 0 16px;border-bottom:1px solid var(--hair3)}
td{padding:20px 0;border-bottom:1px solid var(--hair2);letter-spacing:.2px}
td.num,th.num{text-align:right;font-family:var(--mono)}
tr.hi td{color:var(--ink);font-weight:600}
tr.dim td{color:var(--msoft)}
"""

MARK = ('<svg viewBox="0 0 28 16" width="34" height="20"><line x1="7" y1="8" x2="21" y2="8" '
        'stroke="currentColor" stroke-width="1"/><circle cx="21" cy="8" r="3.5" fill="none" '
        'stroke="currentColor" stroke-width="1"/><circle cx="7" cy="8" r="3.5" fill="currentColor"/></svg>')

def orbs(spec):
    return "".join(f'<div class="orb" style="width:{w}px;height:{h}px;left:{x}px;top:{y}px;'
                   f'background:var(--{c})"></div>' for x, y, w, h, c in spec)

O_WARM = [(-200, -260, 900, 900, "peach"), (1350, 620, 820, 820, "lav")]
O_COOL = [(1250, -300, 900, 900, "sky"), (-260, 600, 780, 780, "mint")]
O_SOFT = [(-180, 640, 820, 820, "rose"), (1400, -240, 760, 760, "mint")]

def frame(fid, inner, orbspec=O_WARM):
    return f'<div class="frame" id="{fid}">{orbs(orbspec)}<div class="pad">{inner}</div></div>'

def head(kick, mark=True):
    m = f'<div class="mark">{MARK}<span>Twinky</span></div>' if mark else "<span></span>"
    return f'<div class="foot" style="margin-bottom:64px">{m}<span class="kick">{kick}</span></div>'

def board_rows(rows, total):
    mx = max(r[1] for r in rows)
    out = []
    for lbl, n, sample in rows:
        out.append(
            f'<div class="row"><div class="lbl">{html.escape(lbl)}'
            f'<small>{html.escape(sample)}</small>'
            f'<div class="bar" style="width:{max(4, int(n / mx * 100))}%"></div></div>'
            f'<div class="n">{n}</div></div>')
    return "".join(out)

F = []

# 01 title
F.append(frame("f01", f"""
<div class="spacer"></div>
<div class="mark" style="font-size:34px;margin-bottom:40px">{MARK}<span>Twinky</span></div>
<h1>Grounded audience<br>signals for live chat.</h1>
<p class="body" style="margin-top:40px">Every reaction tied to the exact stream moment that
caused it — with the evidence attached, or nothing at all.</p>
<div class="spacer"></div>
<div class="foot"><span class="mono">twinky · micro1 frontier engineering challenge 2026</span>
<span class="pill"><span class="dot"></span>replay · keyless</span></div>""", O_WARM))

# 02 thesis
F.append(frame("f02", f"""{head("the thesis")}
<div class="spacer"></div>
<h2>A chat message is not text.<br>It is a response to something.</h2>
<div class="rule"></div>
<p class="body" style="font-size:28px;max-width:64ch"><span class="mono"
style="font-size:28px;color:var(--ink)">10</span> is meaningless.
<span class="mono" style="font-size:28px;color:var(--ink)">10</span> thirty seconds after
<em>“how would you rate this game?”</em> is a rating.</p>
<div class="spacer"></div>
<p class="small">Chat is only interpretable against the stimulus that caused it — and the stimulus
is in the audio and on the screen, not in the chat.</p>""", O_SOFT))

# 03 the flood
flood = "".join(f"<span>{html.escape(t)}</span>" for t in D["flood_para"][:48])
F.append(frame("f03", f"""{head("stableronaldo · 03:32 · one minute of chat")}
<div class="flood">{flood}</div>
<div class="spacer"></div>
<div class="rule"></div>
<div class="foot"><span class="small">123 messages · no speech in this capture · nothing here
means anything as text</span><span class="pill">raw</span></div>""", O_COOL))

# 04 board — the word game
F.append(frame("f04", f"""{head("what the room answered")}
<div class="trigger"><div class="q">▣ GUESS THE WORD! — <span class="mono"
style="font-size:34px">para_</span></div>
<div class="meta">screen · 09:12 · frame caption · 0 speech segments in this window</div></div>
{board_rows([("para…", 38, "parab · parac · parad · paraf · parag · paral · parallel"),
             ("part…", 18, "party · parth · partly · parts"),
             ("parr…", 5, "parre · parry"),
             ("heli…", 5, "helicopter · helios · helium · helix")], 123)}
<div class="spacer"></div>
<div class="foot"><span class="small">123 messages · 4 rows · 82 singletons not shown</span>
<span class="pill ink"><span class="dot"></span>cause proven</span></div>""", O_COOL))

# 05 board — violet
vs = " · ".join(D["violet_samples"][:4])
F.append(frame("f05", f"""{head("what the room answered")}
<div class="trigger"><div class="q">“What the fuck is going on?”</div>
<div class="meta">speech · 07:21 · transcript segment</div></div>
{board_rows([("violet", 27, vs[:70]),
             ("myers", 13, "myers · MYERS???? · Violet Myers"),
             ("wtf", 11, "wtf · WTF · wtf..."),
             ("noah", 9, "NOAH · noah · W Noah")], 237)}
<div class="spacer"></div>
<div class="foot"><span class="small">237 messages · 4 rows · 179 singletons not shown</span>
<span class="pill ink"><span class="dot"></span>cause proven</span></div>""", O_WARM))

# 06 questions
F.append(frame("f06", f"""{head("questions to you")}
<h3 style="margin-bottom:44px">Fourteen questions this stream.<br>Nine of them never got an
answer.</h3>
{board_rows([("“i thought u loved drama?”", 6, "unanswered · asked after “don’t ever get into drama”"),
             ("“has he played yet?”", 4, "unanswered"),
             ("“what game is this”", 9, "answered at 04:12")], 14)}
<div class="spacer"></div>
<p class="small" style="max-width:70ch">Deciding a question went unanswered requires the
transcript. A chat-only system cannot produce this panel at all.</p>""", O_SOFT))

# 07 gate ledger
F.append(frame("f07", f"""{head("the gate")}
<h2 style="margin-bottom:48px">It refuses to show a cause<br>it cannot prove.</h2>
{board_rows([("E_CIRCULAR_EVIDENCE", 15, "the named cause was itself a chat message"),
             ("E_UNKNOWN_MSG", 3, "cited a message id the fixture does not contain"),
             ("E_TRIGGER_LATE", 1, "the cause arrived after the reaction")], 19)}
<div class="spacer"></div>
<div class="foot"><span class="small">19 of 24 cards rejected on this fixture · every rejection
counted, none hidden</span><span class="pill">deterministic · no model</span></div>""", O_COOL))

# 08 metrics
F.append(frame("f08", f"""{head("measured · 11 frozen cases")}
<h3 style="margin-bottom:44px">The agent loses the headline metric.<br>We publish it anyway.</h3>
<table><tr><th>system</th><th class="num">cards</th><th class="num">trigger accuracy</th>
<th class="num">unsupported</th><th class="num">recall</th></tr>
<tr class="hi"><td>ablation · chat only</td><td class="num">25</td><td class="num">1.000</td>
<td class="num">0.280</td><td class="num">0.091</td></tr>
<tr><td>agent</td><td class="num">23</td><td class="num">0.500</td><td class="num">0.739</td>
<td class="num">0.182</td></tr>
<tr class="dim"><td>baseline</td><td class="num">21</td><td class="num">0.000</td>
<td class="num">0.619</td><td class="num">0.091</td></tr></table>
<div class="spacer"></div>
<p class="small">Every number reproduces from a committed response cache with no API keys and
zero cost.</p>""", O_SOFT))

# 09 mechanism
F.append(frame("f09", f"""{head("removed experiment #2")}
<h3 style="margin-bottom:44px">Where each arm’s triggers actually came from</h3>
<table><tr><th>arm</th><th class="num">abstained</th><th class="num">a chat id</th>
<th class="num">a real speech id</th><th class="num">a real frame id</th></tr>
<tr><td>agent · shipped</td><td class="num">5</td><td class="num">14</td><td class="num">4</td>
<td class="num">0</td></tr>
<tr class="hi"><td>agent · candidates injected</td><td class="num">0</td><td class="num">12</td>
<td class="num">1</td><td class="num">4</td></tr></table>
<div class="rule"></div>
<p class="body">It named a real on-screen event for the first time — and scored worse, because
abstention collapsed from five to zero.</p>
<div class="spacer"></div>
<div class="foot"><span class="mono">$0.0122 · 22 calls · not adopted</span>
<span class="pill">measured, then reverted</span></div>""", O_COOL))

# 10 hot take
F.append(frame("f10", f"""{head("hot take")}
<div class="spacer"></div>
<h2>The ablation won by knowing<br>less and saying nothing.<br>
<span style="color:var(--muted)">This arm lost by knowing more<br>and always committing.</span></h2>
<div class="spacer"></div>
<p class="small">Handed a list of candidates, the model always picked one — and picking one is how
a card becomes scoreable, and therefore wrong.</p>""", O_SOFT))

# 11 reproduce
F.append(frame("f11", f"""{head("reproducibility")}
<h2 style="margin-bottom:48px">No keys. No cost.<br>Byte-identical.</h2>
<div class="card" style="font-family:var(--mono);font-size:24px;line-height:2;color:var(--ink)">
make setup &amp;&amp; make test<br>make baseline &amp;&amp; make replay &amp;&amp; make eval</div>
<div class="rule"></div>
<table><tr><td>model-response cache</td><td class="num">48 hits · 0 misses</td></tr>
<tr><td>tests</td><td class="num">530 passed</td></tr>
<tr><td>total spend, whole project</td><td class="num">$0.43</td></tr></table>
<div class="spacer"></div>""", O_WARM))

# 12 end card
F.append(frame("f12", f"""
<div class="spacer"></div>
<div class="mark" style="font-size:44px;justify-content:center">{MARK}<span>Twinky</span></div>
<p class="body" style="text-align:center;margin:32px auto 0;max-width:44ch">Turns an unreadable
live chat into a small number of verified audience signals.</p>
<div class="spacer"></div>
<div class="foot" style="justify-content:center">
<span class="mono">github.com/tolyaho/twinky</span></div>""", O_SOFT))

# 13-15 mood plates for Dreamina reference (no product claim)
F.append(frame("f13", '<div class="spacer"></div>', O_WARM))
F.append(frame("f14", '<div class="spacer"></div>', O_COOL))
F.append(frame("f15", f"""{head("palette", mark=False)}
<div style="display:flex;gap:0;height:340px;border-radius:24px;overflow:hidden;
border:1px solid var(--hair)">
{''.join(f'<div style="flex:1;background:var(--{c})"></div>' for c in
        ['mint','peach','lav','sky','rose'])}</div>
<div class="rule"></div>
<div style="display:flex;gap:0;height:180px;border-radius:16px;overflow:hidden;
border:1px solid var(--hair)">
{''.join(f'<div style="flex:1;background:{c}"></div>' for c in
        ['#f5f5f5','#f0efed','#d6d3d1','#777169','#4e4e4e','#292524','#0c0a09'])}</div>
<div class="spacer"></div>
<p class="small">Light, warm, editorial. Hairlines instead of shadows. No saturated accent
anywhere — the primary control is a near-black pill.</p>""", O_SOFT))


# 16 before/after split
_bf = "".join(f"<span>{html.escape(t)}</span>" for t in D["flood_para"][:34])
F.append(frame("f16", f"""{head("one minute of stableronaldo")}
<div style="display:grid;grid-template-columns:1fr 1px 1fr;gap:56px;flex:1;min-height:0">
  <div style="display:flex;flex-direction:column;min-height:0">
    <div class="kick" style="margin-bottom:28px">what the streamer sees</div>
    <div class="flood" style="columns:2;font-size:17px;line-height:1.75">{_bf}</div>
  </div>
  <div style="background:var(--hair3)"></div>
  <div style="display:flex;flex-direction:column;min-height:0">
    <div class="kick" style="margin-bottom:28px">what Twinky shows</div>
    <div class="trigger" style="margin-top:0"><div class="q" style="font-size:30px">▣ GUESS THE WORD! — <span class="mono" style="font-size:26px">para_</span></div>
    <div class="meta">screen · 09:12 · 0 speech segments</div></div>
    {board_rows([("para…",38,"parab · parac · parad · paral"),("part…",18,"party · parth · parts"),("parr…",5,"parre · parry")],123)}
  </div></div>
<div class="rule"></div>
<div class="foot"><span class="small">123 messages in · 3 rows out</span><span class="pill ink"><span class="dot"></span>cause proven</span></div>""", O_COOL))

# 17 second word game — ranger
F.append(frame("f17", f"""{head("what the room answered")}
<div class="trigger"><div class="q">▣ GUESS THE WORD! — the word was <span class="mono" style="font-size:34px">ranger</span></div>
<div class="meta">screen · 00:41 · frame caption · 0 speech segments in this window</div></div>
{board_rows([("rang…",21,"range · ranged · ranger · rangers"),("rand…",11,"random · randit · randient"),("stre…",10,"streak · stream · street"),("ranc…",8,"ranch · rancid · rancor")],173)}
<div class="spacer"></div>
<div class="foot"><span class="small">173 messages · 4 rows · the audience solved it before the system did</span><span class="pill ink"><span class="dot"></span>cause proven</span></div>""", O_COOL))

# 18 lower third
F.append(frame("f18", f"""
<div class="spacer"></div>
<div style="display:inline-flex;align-items:center;gap:24px;background:var(--card);
border:1px solid var(--hair3);border-radius:9999px;padding:20px 40px;align-self:flex-start">
{MARK}<span style="font-size:28px">Twinky</span>
<span style="width:1px;height:28px;background:var(--hair3)"></span>
<span class="small" style="font-size:20px">grounded audience signals for live chat</span></div>""", O_SOFT))

DOC = (f"<!doctype html><meta charset=utf-8><style>{CSS}</style>" + "".join(F))
pathlib.Path("/home/claude/bank.html").write_text(DOC, encoding="utf-8")

NAMES = {
 "f01":"02-product-stills/01_title_twinky","f02":"02-product-stills/02_thesis_chat_is_response",
 "f03":"02-product-stills/03_raw_chat_flood","f04":"02-product-stills/04_board_wordgame_para",
 "f05":"02-product-stills/05_board_violet_27","f06":"02-product-stills/06_questions_panel",
 "f07":"02-product-stills/07_gate_ledger","f08":"02-product-stills/08_metrics_table",
 "f09":"02-product-stills/09_mechanism_table","f10":"03-titles/10_hot_take",
 "f11":"02-product-stills/11_reproducibility","f12":"03-titles/12_end_card",
 "f13":"04-mood/13_orbs_warm","f14":"04-mood/14_orbs_cool","f15":"04-mood/15_palette","f16":"02-product-stills/16_before_after_split","f17":"02-product-stills/17_board_wordgame_ranger","f18":"03-titles/18_lower_third",
}

from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={"width":1920,"height":1080}, device_scale_factor=1)
    pg.goto("file:///home/claude/bank.html")
    pg.wait_for_timeout(600)
    for fid, name in NAMES.items():
        path = OUT / f"{name}.png"
        path.parent.mkdir(parents=True, exist_ok=True)
        pg.locator(f"#{fid}").screenshot(path=str(path))
    b.close()
print("rendered", len(NAMES))
